// filters.js

import { renderCheckboxList, getCheckedValues } from "./helpers.js";
import {
  renderProductsPage,
  setCurrentPage,
  getPageSize,
} from "./productFlow.js";

let allProducts = [];
let filteredProducts = [];
let currentCategory = "";
let defaultMinPrice = 0;
let defaultMaxPrice = 0;

export function setAllProducts(data) {
  allProducts = data;
}

export function setCurrentCategory(cat) {
  currentCategory = cat;
}

export function getFilteredProducts() {
  return filteredProducts;
}

export function initFilters() {
  const priceMin = document.getElementById("priceMin");
  const priceMax = document.getElementById("priceMax");
  const priceMinVal = document.getElementById("priceMinVal");
  const priceMaxVal = document.getElementById("priceMaxVal");

  const prices = allProducts
    .map((p) => p.prices?.Ekua)
    .filter((v) => v != null);
  if (prices.length === 0) return;

  defaultMinPrice = Math.min(...prices);
  defaultMaxPrice = Math.max(...prices);

  priceMin.min = priceMax.min = defaultMinPrice;
  priceMin.max = priceMax.max = defaultMaxPrice;
  priceMin.value = defaultMinPrice;
  priceMax.value = defaultMaxPrice;
  priceMinVal.textContent = `$${defaultMinPrice}`;
  priceMaxVal.textContent = `$${defaultMaxPrice}`;

  document.getElementById("compatibilityOnly").checked = false;
  document.getElementById("only3d").checked = false;
  document.getElementById("component-search").value = "";

  const cpuFilterBlock = document.getElementById("cpu-filters");
  cpuFilterBlock.style.display = currentCategory === "CPU" ? "block" : "none";

  if (currentCategory === "CPU") {
    const socketSet = new Set();
    const archSet = new Set();
    const igpuSet = new Set();

    for (const p of allProducts) {
      const specs = p.specs || {};
      if (specs.socket) socketSet.add(specs.socket);
      if (specs.microarchitecture) archSet.add(specs.microarchitecture);
      if (specs.specifications?.integratedGraphics?.model)
        igpuSet.add(specs.specifications.integratedGraphics.model);
    }

    renderCheckboxList("socketFilter", socketSet, applyFiltersAndRender);
    renderCheckboxList(
      "microarchitectureFilter",
      archSet,
      applyFiltersAndRender
    );
    renderCheckboxList(
      "integratedGraphicsFilter",
      igpuSet,
      applyFiltersAndRender
    );
  }
  // Показываем/прячем блок GPU-фильтров
  const gpuFilterBlock = document.getElementById("gpu-filters");
  gpuFilterBlock.style.display = currentCategory === "GPU" ? "block" : "none";

  if (currentCategory === "GPU") {
    const chipsetSet = new Set();
    const memoryTypeSet = new Set();
    const interfaceSet = new Set();
    const manufacturerSet = new Set();

    for (const p of allProducts) {
      const specs = p.specs || {};
      if (specs.chipset) chipsetSet.add(specs.chipset);
      if (specs.memory_type) memoryTypeSet.add(specs.memory_type);
      if (specs.interface) interfaceSet.add(specs.interface);
      if (specs.metadata?.manufacturer)
        manufacturerSet.add(specs.metadata.manufacturer);
    }

    renderCheckboxList("chipsetFilter", chipsetSet, applyFiltersAndRender);
    renderCheckboxList(
      "memoryTypeFilter",
      memoryTypeSet,
      applyFiltersAndRender
    );
    renderCheckboxList("interfaceFilter", interfaceSet, applyFiltersAndRender);
    renderCheckboxList(
      "manufacturerFilter",
      manufacturerSet,
      applyFiltersAndRender
    );
  }

  // Motherboard
  const mbFilterBlock = document.getElementById("mb-filters");
  mbFilterBlock.style.display =
    currentCategory === "Motherboard" ? "block" : "none";
  if (currentCategory === "Motherboard") {
    const socketSet = new Set();
    const formFactorSet = new Set();
    const chipsetSet = new Set();
    const ramTypeSet = new Set();
    const manufacturerSet = new Set();

    for (const p of allProducts) {
      const s = p.specs || {};
      if (p.specs?.socket) socketSet.add(s.socket);
      if (s.form_factor) formFactorSet.add(s.form_factor);
      if (s.chipset) chipsetSet.add(s.chipset);
      if (s.memory?.ram_type) ramTypeSet.add(s.memory.ram_type);
      if (s.metadata?.manufacturer)
        manufacturerSet.add(s.metadata.manufacturer);
    }

    renderCheckboxList("socketFilter-mb", socketSet, applyFiltersAndRender);
    renderCheckboxList(
      "formFactorFilter",
      formFactorSet,
      applyFiltersAndRender
    );
    renderCheckboxList("mbChipsetFilter", chipsetSet, applyFiltersAndRender);
    renderCheckboxList("ramTypeFilter", ramTypeSet, applyFiltersAndRender);
    renderCheckboxList(
      "mbManufacturerFilter",
      manufacturerSet,
      applyFiltersAndRender
    );
  }

  // PC Case
  const caseFilterBlock = document.getElementById("case-filters");
  if (!caseFilterBlock) {
    console.error("initFilters: #case-filters не найден");
  } else {
    const isCase = currentCategory.toLowerCase() === "pccase";
    caseFilterBlock.style.display = isCase ? "block" : "none";

    if (isCase) {
      const formFactorSet = new Set();
      const sidePanelSet = new Set();
      const manufacturerSet = new Set();

      for (const p of allProducts) {
        const s = p.specs || {};
        if (s.form_factor) formFactorSet.add(s.form_factor);
        if (s.side_panel) sidePanelSet.add(s.side_panel);
        if (s.metadata?.manufacturer)
          manufacturerSet.add(s.metadata.manufacturer);
      }

      renderCheckboxList(
        "caseFormFactorFilter",
        formFactorSet,
        applyFiltersAndRender
      );
      renderCheckboxList(
        "sidePanelFilter",
        sidePanelSet,
        applyFiltersAndRender
      );
      renderCheckboxList(
        "caseManufacturerFilter",
        manufacturerSet,
        applyFiltersAndRender
      );
    }
  }

  // CPUCooler
  const coolerFilterBlock = document.getElementById("cooler-filters");
  if (!coolerFilterBlock) {
    console.error("initFilters: #cooler-filters не знайдено");
  } else {
    const isCooler = currentCategory.toLowerCase() === "cpucooler";
    coolerFilterBlock.style.display = isCooler ? "block" : "none";

    if (isCooler) {
      const manSet = new Set();
      const waterSet = new Set();

      for (const p of allProducts) {
        const s = p.specs || {};
        if (s.metadata?.manufacturer) {
          manSet.add(s.metadata.manufacturer);
        }
        // булеве → текст
        if (typeof s.water_cooled === "boolean") {
          waterSet.add(s.water_cooled ? "Yes" : "No");
        }
      }

      renderCheckboxList(
        "coolerManufacturerFilter",
        manSet,
        applyFiltersAndRender
      );
      renderCheckboxList("waterCooledFilter", waterSet, applyFiltersAndRender);
    }
  }

  // RAM
  const ramFilterBlock = document.getElementById("ram-filters");
  if (!ramFilterBlock) {
    console.error("initFilters: #ram-filters не найден");
  } else {
    const isRam = currentCategory.toLowerCase() === "ram";
    ramFilterBlock.style.display = isRam ? "block" : "none";

    if (isRam) {
      const typeSet = new Set();
      const formFactorSet = new Set();
      const eccSet = new Set();
      const regSet = new Set();
      const manSet = new Set();
      const heatSet = new Set();
      const rgbSet = new Set();

      for (const p of allProducts) {
        const s = p.specs || {};
        if (s.ram_type) typeSet.add(s.ram_type);
        if (s.form_factor) formFactorSet.add(s.form_factor);
        if (typeof s.ecc === "boolean") eccSet.add(s.ecc ? "Yes" : "No");
        else if (s.ecc != null) eccSet.add(String(s.ecc));
        if (typeof s.registered === "boolean")
          regSet.add(s.registered ? "Yes" : "No");
        else if (s.registered != null) regSet.add(String(s.registered));
        if (s.metadata?.manufacturer) manSet.add(s.metadata.manufacturer);
        if (typeof s.heat_spreader === "boolean")
          heatSet.add(s.heat_spreader ? "Yes" : "No");
        if (typeof s.rgb === "boolean") rgbSet.add(s.rgb ? "Yes" : "No");
      }

      renderCheckboxList("ramTypeFilter-RAM", typeSet, applyFiltersAndRender);
      renderCheckboxList(
        "ramFormFactorFilter",
        formFactorSet,
        applyFiltersAndRender
      );
      renderCheckboxList("eccFilter", eccSet, applyFiltersAndRender);
      renderCheckboxList("registeredFilter", regSet, applyFiltersAndRender);
      renderCheckboxList(
        "ramManufacturerFilter",
        manSet,
        applyFiltersAndRender
      );
      renderCheckboxList("heatSpreaderFilter", heatSet, applyFiltersAndRender);
      renderCheckboxList("rgbFilter", rgbSet, applyFiltersAndRender);
    }
  }

  // Storage
  const storageFilterBlock = document.getElementById("storage-filters");
  if (!storageFilterBlock) {
    console.error("initFilters: #storage-filters не найден");
  } else {
    const isStorage = currentCategory.toLowerCase() === "storage";
    storageFilterBlock.style.display = isStorage ? "block" : "none";

    if (isStorage) {
      const typeSet = new Set();
      const ffSet = new Set();
      const ifaceSet = new Set();
      const manSet = new Set();
      const nvmeSet = new Set();

      for (const p of allProducts) {
        const s = p.specs || {};
        if (s.type) typeSet.add(s.type);
        if (s.form_factor) ffSet.add(s.form_factor);
        if (s.interface) ifaceSet.add(s.interface);
        if (s.metadata?.manufacturer) manSet.add(s.metadata.manufacturer);
        if (typeof s.nvme === "boolean") nvmeSet.add(s.nvme ? "Yes" : "No");
      }

      renderCheckboxList("storageTypeFilter", typeSet, applyFiltersAndRender);
      renderCheckboxList(
        "storageFormFactorFilter",
        ffSet,
        applyFiltersAndRender
      );
      renderCheckboxList(
        "storageInterfaceFilter",
        ifaceSet,
        applyFiltersAndRender
      );
      renderCheckboxList(
        "storageManufacturerFilter",
        manSet,
        applyFiltersAndRender
      );
      renderCheckboxList("nvmeFilter", nvmeSet, applyFiltersAndRender);
    }
  }

  // PSU
  const psuFilterBlock = document.getElementById("psu-filters");
  if (!psuFilterBlock) {
    console.error("initFilters: #psu-filters не найден");
  } else {
    const isPsu = currentCategory.toLowerCase() === "psu";
    psuFilterBlock.style.display = isPsu ? "block" : "none";

    if (isPsu) {
      const ffSet = new Set();
      const effSet = new Set();
      const modSet = new Set();
      const manSet = new Set();

      for (const p of allProducts) {
        const s = p.specs || {};
        if (s.form_factor) ffSet.add(s.form_factor);
        if (s.efficiency_rating) effSet.add(s.efficiency_rating);
        if (typeof s.modular === "boolean")
          modSet.add(s.modular ? "Yes" : "No");
        else if (s.modular != null) modSet.add(String(s.modular));
        if (s.metadata?.manufacturer) manSet.add(s.metadata.manufacturer);
      }

      renderCheckboxList("psuFormFactorFilter", ffSet, applyFiltersAndRender);
      renderCheckboxList(
        "efficiencyRatingFilter",
        effSet,
        applyFiltersAndRender
      );
      renderCheckboxList("modularFilter", modSet, applyFiltersAndRender);
      renderCheckboxList(
        "psuManufacturerFilter",
        manSet,
        applyFiltersAndRender
      );
    }
  }

  // Monitor
  const monitorFilterBlock = document.getElementById("monitor-filters");
  if (!monitorFilterBlock) {
    console.error("initFilters: #monitor-filters не найден");
  } else {
    const isMonitor = currentCategory.toLowerCase() === "monitor";
    monitorFilterBlock.style.display = isMonitor ? "block" : "none";

    if (isMonitor) {
      const brandSet = new Set();
      const refreshSet = new Set();
      const sizeSet = new Set();
      const vertSet = new Set();
      const horizSet = new Set();

      for (const p of allProducts) {
        const s = p.specs || {};
        if (s.metadata?.manufacturer) brandSet.add(s.metadata.manufacturer);
        if (s.refresh_rate != null) refreshSet.add(String(s.refresh_rate));
        if (s.screen_size != null) sizeSet.add(String(s.screen_size));
        if (s.resolution?.verticalRes != null)
          vertSet.add(String(s.resolution.verticalRes));
        if (s.resolution?.horizontalRes != null)
          horizSet.add(String(s.resolution.horizontalRes));
      }

      renderCheckboxList("monitorBrandFilter", brandSet, applyFiltersAndRender);
      renderCheckboxList(
        "refreshRateFilter",
        refreshSet,
        applyFiltersAndRender
      );
      renderCheckboxList("screenSizeFilter", sizeSet, applyFiltersAndRender);
      renderCheckboxList("verticalResFilter", vertSet, applyFiltersAndRender);
      renderCheckboxList(
        "horizontalResFilter",
        horizSet,
        applyFiltersAndRender
      );
    }
  }
}

export function applyFiltersAndRender() {
  const minP = Number(document.getElementById("priceMin").value);
  const maxP = Number(document.getElementById("priceMax").value);
  const defaultMin = defaultMinPrice;
  const defaultMax = defaultMaxPrice;
  const query = document
    .getElementById("component-search")
    .value.trim()
    .toLowerCase();
  const compOnly = document.getElementById("compatibilityOnly").checked;
  const only3d = document.getElementById("only3d").checked;

  const filtered = allProducts.filter((p) => {
    const price = p.prices?.Ekua ?? 0;
    if (price < minP || price > maxP) return false;
    if (compOnly && p.specs?.compatible === false) return false;

    const name = (p.specs?.metadata?.name || "").toLowerCase();
    if (query) {
      // Разбиваем строку на слова (по пробелам, табам и т.п.)
      const words = query.trim().split(/\s+/);

      // Если хоть одно слово не содержится в name — фильтруем
      if (!words.every((word) => name.includes(word))) {
        return false;
      }
    }

    if (currentCategory === "CPU") {
      const sockets = getCheckedValues("socketFilter");
      const archs = getCheckedValues("microarchitectureFilter");
      const igpus = getCheckedValues("integratedGraphicsFilter");

      if (
        (sockets.length && !sockets.includes(p.specs?.socket)) ||
        (archs.length && !archs.includes(p.specs?.microarchitecture)) ||
        (igpus.length &&
          !igpus.includes(p.specs?.specifications?.integratedGraphics?.model))
      ) {
        return false;
      }
    }

    // GPU-фильтрация
    if (currentCategory === "GPU") {
      const chipsets = getCheckedValues("chipsetFilter");
      const memoryTypes = getCheckedValues("memoryTypeFilter");
      const interfaces = getCheckedValues("interfaceFilter");
      const manufacturers = getCheckedValues("manufacturerFilter");

      if (
        (chipsets.length && !chipsets.includes(p.specs?.chipset)) ||
        (memoryTypes.length && !memoryTypes.includes(p.specs?.memory_type)) ||
        (interfaces.length && !interfaces.includes(p.specs?.interface)) ||
        (manufacturers.length &&
          !manufacturers.includes(p.specs?.metadata?.manufacturer))
      ) {
        return false;
      }
    }

    // Motherboard
    if (currentCategory === "Motherboard") {
      const sockets = getCheckedValues("socketFilter-mb");
      const formFactors = getCheckedValues("formFactorFilter");
      const mbChipsets = getCheckedValues("mbChipsetFilter");
      const ramTypes = getCheckedValues("ramTypeFilter");
      const mbMans = getCheckedValues("mbManufacturerFilter");

      if (
        (sockets.length && !sockets.includes(p.specs?.socket)) ||
        (formFactors.length && !formFactors.includes(p.specs?.form_factor)) ||
        (mbChipsets.length && !mbChipsets.includes(p.specs?.chipset)) ||
        (ramTypes.length && !ramTypes.includes(p.specs?.memory?.ram_type)) ||
        (mbMans.length && !mbMans.includes(p.specs?.metadata?.manufacturer))
      ) {
        return false;
      }
    }

    // PC Case
    if (currentCategory.toLowerCase() === "pccase") {
      const ff = getCheckedValues("caseFormFactorFilter");
      const sp = getCheckedValues("sidePanelFilter");
      const man = getCheckedValues("caseManufacturerFilter");

      if (
        (ff.length && !ff.includes(p.specs?.form_factor)) ||
        (sp.length && !sp.includes(p.specs?.side_panel)) ||
        (man.length && !man.includes(p.specs?.metadata?.manufacturer))
      ) {
        return false;
      }
    }

    // CPUCooler
    if (currentCategory.toLowerCase() === "cpucooler") {
      const mans = getCheckedValues("coolerManufacturerFilter");
      const waters = getCheckedValues("waterCooledFilter");

      if (
        (mans.length && !mans.includes(p.specs?.metadata?.manufacturer)) ||
        (waters.length &&
          !waters.includes(
            typeof p.specs?.water_cooled === "boolean"
              ? p.specs.water_cooled
                ? "Yes"
                : "No"
              : ""
          ))
      ) {
        return false;
      }
    }

    // RAM
    if (currentCategory.toLowerCase() === "ram") {
      const types = getCheckedValues("ramTypeFilter-RAM");
      const forms = getCheckedValues("ramFormFactorFilter");
      const eccs = getCheckedValues("eccFilter");
      const regs = getCheckedValues("registeredFilter");
      const mans = getCheckedValues("ramManufacturerFilter");
      const heats = getCheckedValues("heatSpreaderFilter");
      const rgbs = getCheckedValues("rgbFilter");

      const s = p.specs || {};
      const eccVal =
        typeof s.ecc === "boolean"
          ? s.ecc
            ? "Yes"
            : "No"
          : String(s.ecc || "");
      const regVal =
        typeof s.registered === "boolean"
          ? s.registered
            ? "Yes"
            : "No"
          : String(s.registered || "");
      const heatVal =
        typeof s.heat_spreader === "boolean"
          ? s.heat_spreader
            ? "Yes"
            : "No"
          : "";
      const rgbVal = typeof s.rgb === "boolean" ? (s.rgb ? "Yes" : "No") : "";

      if (
        (types.length && !types.includes(s.ram_type)) ||
        (forms.length && !forms.includes(s.form_factor)) ||
        (eccs.length && !eccs.includes(eccVal)) ||
        (regs.length && !regs.includes(regVal)) ||
        (mans.length && !mans.includes(s.metadata?.manufacturer)) ||
        (heats.length && !heats.includes(heatVal)) ||
        (rgbs.length && !rgbs.includes(rgbVal))
      ) {
        return false;
      }
    }

    // Storage
    if (currentCategory.toLowerCase() === "storage") {
      const types = getCheckedValues("storageTypeFilter");
      const ffs = getCheckedValues("storageFormFactorFilter");
      const ifaces = getCheckedValues("storageInterfaceFilter");
      const mans = getCheckedValues("storageManufacturerFilter");
      const nvmes = getCheckedValues("nvmeFilter");

      const s = p.specs || {};
      const nvVal = typeof s.nvme === "boolean" ? (s.nvme ? "Yes" : "No") : "";

      if (
        (types.length && !types.includes(s.type)) ||
        (ffs.length && !ffs.includes(s.form_factor)) ||
        (ifaces.length && !ifaces.includes(s.interface)) ||
        (mans.length && !mans.includes(s.metadata?.manufacturer)) ||
        (nvmes.length && !nvmes.includes(nvVal))
      ) {
        return false;
      }
    }

    // PSU
    if (currentCategory.toLowerCase() === "psu") {
      const ffs = getCheckedValues("psuFormFactorFilter");
      const effs = getCheckedValues("efficiencyRatingFilter");
      const mods = getCheckedValues("modularFilter");
      const mans = getCheckedValues("psuManufacturerFilter");

      const s = p.specs || {};
      const modVal =
        typeof s.modular === "boolean"
          ? s.modular
            ? "Yes"
            : "No"
          : String(s.modular || "");

      if (
        (ffs.length && !ffs.includes(s.form_factor)) ||
        (effs.length && !effs.includes(s.efficiency_rating)) ||
        (mods.length && !mods.includes(modVal)) ||
        (mans.length && !mans.includes(s.metadata?.manufacturer))
      ) {
        return false;
      }
    }

    // Monitor
    if (currentCategory.toLowerCase() === "monitor") {
      const brands = getCheckedValues("monitorBrandFilter");
      const rates = getCheckedValues("refreshRateFilter");
      const sizes = getCheckedValues("screenSizeFilter");
      const verts = getCheckedValues("verticalResFilter");
      const hors = getCheckedValues("horizontalResFilter");

      const s = p.specs || {};
      const ratesVal = s.refresh_rate != null ? String(s.refresh_rate) : "";
      const sizesVal = s.screen_size != null ? String(s.screen_size) : "";
      const vertVal =
        s.resolution?.verticalRes != null
          ? String(s.resolution.verticalRes)
          : "";
      const horizVal =
        s.resolution?.horizontalRes != null
          ? String(s.resolution.horizontalRes)
          : "";

      if (
        (brands.length && !brands.includes(s.metadata?.manufacturer)) ||
        (rates.length && !rates.includes(ratesVal)) ||
        (sizes.length && !sizes.includes(sizesVal)) ||
        (verts.length && !verts.includes(vertVal)) ||
        (hors.length && !hors.includes(horizVal))
      ) {
        return false;
      }
    }

    return true;
  });

  const filtersApplied =
    minP > defaultMin ||
    maxP < defaultMax ||
    query !== "" ||
    compOnly ||
    only3d;

  filteredProducts = filtersApplied
    ? filtered
    : [
        ...filtered.filter((p) => p.prices?.Ekua !== 0),
        ...filtered.filter((p) => p.prices?.Ekua === 0),
      ];

  setCurrentPage(1);
  renderProductsPage(filteredProducts);
}
